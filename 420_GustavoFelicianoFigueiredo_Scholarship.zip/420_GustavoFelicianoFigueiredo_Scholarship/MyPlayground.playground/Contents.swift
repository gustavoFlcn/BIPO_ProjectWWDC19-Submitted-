//:WELCOME TO THE BIPO.

//:Bipo, is the nickname given this project to the Scholarships, as it comes in a game that tackles the subject of bipolarity. I thought about this subject because of my girlfriend who has bipolarity. At the beginning of my courtship it was very difficult to understand her and it was very difficult to learn how to act when she went through the phases of bipolarity, especially the phase of depression, which was the phase she suffered most. And by not knowing how to act I could not help reducing her suffering. I thought it was cool to pass on that feeling to each of you. The feeling of helping a person with bipolarity who is in the phase of depression.

//:The mechanics of the game are very simple. You need to piece together and assemble the heart, which means your help to that person. Each piece of the puzzle means your action, if you choose a piece that represents a bad action it will not be accepted. After completing the heart, your help is ready and the girl will feel better.

//:A BRIEF TUTORIAL: Press the desired part, drag to another desired part and release. (They will join and a piece will appear with the two you have joined. This new piece will not be able to be moved, so drag the other two right pieces close to it one by one)


// CREATE BY GUSTAVO FELICIANO FIGUEIREDO
// FOR SCHOLARSHIPS 19

import PlaygroundSupport
import SpriteKit

let width = 500
let height = 800
let xBoard = 450
let yBoard = 501



class GameScene: SKScene {
    
    //public var label: SKLabelNode!
    var board = SKSpriteNode(imageNamed: "board")
    var fundo = SKSpriteNode(imageNamed: "background")
    
    //pecas do quebraCabeca
    //CORACAO 1
    // SIZE OF THE PUZZLES
    let tamXpeca = 100
    let tamYpeca = 100
    //pecas sozinhas
    let peca1Core1 = SKSpriteNode(imageNamed: "puzzle1")
    let peca2Core1 = SKSpriteNode(imageNamed: "puzzle2")
    let peca3Core1 = SKSpriteNode(imageNamed: "puzzle3")
    let peca4Core1 = SKSpriteNode(imageNamed: "puzzle4")
    //pecas fakes
    let fake1core1 = SKSpriteNode(imageNamed: "joke1")
    let fake2core1 = SKSpriteNode(imageNamed: "joke2")
    //PECAS DE DUAS PARTES
    let peca1_2 = SKSpriteNode(imageNamed: "peca1_2")
    let peca1_3 = SKSpriteNode(imageNamed: "peca1_3")
    let peca2_4 = SKSpriteNode(imageNamed: "peca2_4")
    let peca3_4 = SKSpriteNode(imageNamed: "peca3_4")
    // PECAS DE TRES PARTES
    let peca1_2_3 = SKSpriteNode(imageNamed: "peca1_2_3")
    let peca1_2_4 = SKSpriteNode(imageNamed: "peca1_2_4")
    let peca1_3_4 = SKSpriteNode(imageNamed: "peca1_3_4")
    let peca2_3_4 = SKSpriteNode(imageNamed: "peca2_3_4")
    //CORACAO COMPLETO
    let completHeart = SKSpriteNode(imageNamed: "completoHeart")
    
    //POSITIOING OF THE PIECES WITH MORE THAN ONE PIECE
    let position7 = CGPoint(x: 250, y: 260)
    
    //GIRL
    let girlSad = SKSpriteNode(imageNamed: "personSad")
    let girlHappy = SKSpriteNode(imageNamed: "personHappy")
    
    // POSITION OF THE GIRL
    let positionGirl = CGPoint(x: 120, y: 625)
    
    // SIZE OF THE GIRL
    let sizeGirl = CGSize(width: 150, height: 230)
    
    //Classe do tipo nó para drag and drop
    private var currentNode: SKNode?
    
    //Text of the girl
    var speakOftheGirl: SKLabelNode!
    
    override func didMove(to view: SKView) {
        fundo.position = CGPoint(x: width / 2, y: height / 2 )
        addChild(fundo)
        
        
        //ADD SAD GIRL ON VIEW
        addGirl(flag: false)
        //ADD HAPPY GIRL ON VIEW
        addGirl(flag: true)
        self.girlHappy.isHidden = true
        
        //ADD BOAR ON VIEW
        board.position = CGPoint(x: 250, y: 285)
        addChild(board)
        
        //ADICIONAR PECAS A VIEW
        addPecas()
        
        //DEFITION SPEAK OF THE GIRL
        self.speakOftheGirl = SKLabelNode(fontNamed: "Arial Rounded MT Bold")
        self.speakOftheGirl!.text = "Everything seems so dull, I am unwell and without encouragement for anything, and I wanted the help of someone." +
        "can you help me!"
        self.speakOftheGirl.numberOfLines = 2
        self.speakOftheGirl.preferredMaxLayoutWidth = 250
        self.speakOftheGirl!.fontSize = 18
        self.speakOftheGirl!.fontColor = SKColor.black
        self.speakOftheGirl!.position = CGPoint(x: 350, y: 610)
        addChild(self.speakOftheGirl!)
    }
    
    // FUNCAO PARA ADICIONAR MENINA E TEXTO
    func addGirl(flag: Bool){
        // se for igual a false add sad girl, mas se for igual a true add happy girl
        if(flag == false){
            self.girlSad.size = sizeGirl
            self.girlSad.position = positionGirl
            addChild(self.girlSad)
        }else{
            self.girlHappy.size = sizeGirl
            self.girlHappy.position = positionGirl
            addChild(girlHappy)
        }
    }

    //ADICIONANDO PECAS EM SUAS POSICOES
    func addPecas(){
        ///posicao das pecas
        let position1 = CGPoint(x: 100, y: 240)
        let position2 = CGPoint(x: 100, y: 100)
        let position3 = CGPoint(x: 400, y: 270)
        let position4 = CGPoint(x: 400, y: 390)
        let position5 = CGPoint(x: 400, y: 100)
        let position6 = CGPoint(x: 100, y: 390)
        
        
        //definindo posicao das pecas
        //CORE1
        //pecas sozinhas
        self.peca1Core1.size = CGSize(width: tamXpeca, height: tamYpeca)
        self.peca1Core1.position = position1
        self.peca1Core1.name = "peca1core1"
        addChild(self.peca1Core1)
        self.peca2Core1.position = position2
        self.peca2Core1.name = "peca2core1"
        self.peca2Core1.size = CGSize(width: tamXpeca, height: tamYpeca)
        addChild(self.peca2Core1)
        self.peca3Core1.position = position3
        self.peca3Core1.name = "peca3core1"
        self.peca3Core1.size = CGSize(width: tamXpeca, height: tamYpeca)
        addChild(self.peca3Core1)
        self.peca4Core1.position = position4
        self.peca4Core1.name = "peca4core1"
        self.peca4Core1.size = CGSize(width: tamXpeca, height: tamYpeca)
        addChild(self.peca4Core1)
        //pecas fakes
        self.fake1core1.position = position5
        self.fake1core1.name = "fake1core1"
        self.fake1core1.size = CGSize(width: tamXpeca, height: tamYpeca)
        addChild(self.fake1core1)
        self.fake2core1.position = position6
        self.fake2core1.name = "fake2core1"
        self.fake2core1.size = CGSize(width: tamXpeca, height: tamYpeca)
        addChild(self.fake2core1)
        //PECAS DE DUAS PARTES
        self.peca1_2.size = CGSize(width: tamXpeca+80, height: tamYpeca)
        self.peca1_2.name = "peca1_2"
        
        self.peca1_3.size = CGSize(width: tamXpeca+10, height: tamYpeca+100)
        self.peca1_3.name = "peca1_3"
        
        self.peca2_4.size = CGSize(width: tamXpeca+10, height: tamYpeca+100)
        self.peca2_4.name = "peca2_4"
        
        self.peca3_4.size = CGSize(width: tamXpeca+80, height: tamYpeca)
        self.peca3_4.name = "peca3_4"
        
        //PECAS DE TRES PARTES
        self.peca1_2_3.size = CGSize(width: tamXpeca+90, height: tamYpeca+80)
        self.peca1_2_3.name = "peca1_2_3"
        
        self.peca1_2_4.size = CGSize(width: tamXpeca+90, height: tamYpeca+80)
        self.peca1_2_4.name = "peca1_2_4"
        
        self.peca1_3_4.size = CGSize(width: tamXpeca+90, height: tamYpeca+80)
        self.peca1_3_4.name = "peca1_3_4"
        
        self.peca2_3_4.size = CGSize(width: tamXpeca+90, height: tamYpeca+80)
        self.peca2_3_4.name = "peca2_3_4"
        
        //COMPLET HEART
        self.completHeart.size = CGSize(width: tamXpeca+150, height: tamYpeca+150)
        self.completHeart.name = "completoHeart"
    }
    
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let touch = touches.first{
            let location = touch.location(in: self)
            
            let touchedNodes = self.nodes(at: location)
            for node in touchedNodes.reversed(){
                
                switch node.name {
                case self.peca1Core1.name:
                    self.currentNode = peca1Core1
                case self.peca2Core1.name:
                    self.currentNode = peca2Core1
                case self.peca3Core1.name:
                    self.currentNode = peca3Core1
                case self.peca4Core1.name:
                    self.currentNode = peca4Core1
                case self.fake1core1.name:
                    self.currentNode = fake1core1
                case self.fake2core1.name:
                    self.currentNode = fake2core1
                default: break
                }
            }
        }
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let touch = touches.first, let node = self.currentNode{
            let touchLocation = touch.location(in: self)
            node.position = touchLocation
        }
    }
    
    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.currentNode = nil
    }
    
    //ACAO QUE DEVE ACONTECER APOS O NODE FOR SOLTADO
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        switch currentNode?.name {
        case "peca1core1":
            colisao(colisao1: peca1Core1, colisao2: peca2Core1, isFake: false, subPeca: peca1_2, isComplet: false)
            colisao(colisao1: peca1Core1, colisao2: peca3Core1, isFake: false, subPeca: peca1_3, isComplet: false)
            colisao(colisao1: peca1Core1, colisao2: peca3_4, isFake: false, subPeca: peca1_3_4, isComplet: false)
            colisao(colisao1: peca1Core1, colisao2: peca2_4, isFake: false, subPeca: peca1_2_4, isComplet: false)
            colisao(colisao1: peca1Core1, colisao2: peca2_3_4, isFake: false, subPeca: completHeart, isComplet: true)
            colisao(colisao1: peca1Core1, colisao2: peca4Core1, isFake: true, subPeca: nil, isComplet: false)
            colisao(colisao1: peca1Core1, colisao2: fake1core1, isFake: true, subPeca: nil, isComplet: false)
            colisao(colisao1: peca1Core1, colisao2: fake2core1, isFake: true, subPeca: nil, isComplet: false)
        case "peca2core1":
            colisao(colisao1: peca2Core1, colisao2: peca1Core1, isFake: false, subPeca: peca1_2, isComplet: false)
            colisao(colisao1: peca2Core1, colisao2: peca4Core1, isFake: false, subPeca: peca2_4, isComplet: false)
            colisao(colisao1: peca2Core1, colisao2: peca3_4, isFake: false, subPeca: peca2_3_4, isComplet: false)
            colisao(colisao1: peca2Core1, colisao2: peca1_3, isFake: false, subPeca: peca1_2_3, isComplet: false)
            colisao(colisao1: peca2Core1, colisao2: peca1_3_4, isFake: false, subPeca: completHeart, isComplet: true)
            colisao(colisao1: peca2Core1, colisao2: peca3Core1, isFake: true, subPeca: nil, isComplet: false)
            colisao(colisao1: peca2Core1, colisao2: fake1core1, isFake: true, subPeca: nil, isComplet: false)
            colisao(colisao1: peca2Core1, colisao2: fake2core1, isFake: true, subPeca: nil, isComplet: false)
        case "peca3core1":
            colisao(colisao1: peca3Core1, colisao2: peca1Core1, isFake: false, subPeca: peca1_3, isComplet: false)
            colisao(colisao1: peca3Core1, colisao2: peca4Core1, isFake: false, subPeca: peca3_4, isComplet: false)
            colisao(colisao1: peca3Core1, colisao2: peca1_2, isFake: false, subPeca: peca1_2_3, isComplet: false)
            colisao(colisao1: peca3Core1, colisao2: peca2_4, isFake: false, subPeca: peca2_3_4, isComplet: false)
            colisao(colisao1: peca3Core1, colisao2: peca1_2_4, isFake: false, subPeca: completHeart, isComplet: true)
            colisao(colisao1: peca3Core1, colisao2: peca2Core1, isFake: true, subPeca: nil, isComplet: false)
            colisao(colisao1: peca3Core1, colisao2: fake1core1, isFake: true, subPeca: nil, isComplet: false)
            colisao(colisao1: peca3Core1, colisao2: fake2core1, isFake: true, subPeca: nil, isComplet: false)
        case "peca4core1":
            colisao(colisao1: peca4Core1, colisao2: peca2Core1, isFake: false, subPeca: peca2_4, isComplet: false)
            colisao(colisao1: peca4Core1, colisao2: peca3Core1, isFake: false, subPeca: peca3_4, isComplet: false)
            colisao(colisao1: peca4Core1, colisao2: peca1_2, isFake: false, subPeca: peca1_2_4, isComplet: false)
            colisao(colisao1: peca4Core1, colisao2: peca1_3, isFake: false, subPeca: peca1_3_4, isComplet: false)
            colisao(colisao1: peca4Core1, colisao2: peca1_2_3, isFake: false, subPeca: completHeart, isComplet: true)
            colisao(colisao1: peca4Core1, colisao2: peca1Core1, isFake: true, subPeca: nil, isComplet: false)
            colisao(colisao1: peca4Core1, colisao2: fake1core1, isFake: true, subPeca: nil, isComplet: false)
            colisao(colisao1: peca4Core1, colisao2: fake2core1, isFake: true, subPeca: nil, isComplet: false)
        case "fake1core1":
            colisao(colisao1: fake1core1, colisao2: peca1Core1, isFake: true, subPeca: nil, isComplet: false)
            colisao(colisao1: fake1core1, colisao2: peca2Core1, isFake: true, subPeca: nil, isComplet: false)
            colisao(colisao1: fake1core1, colisao2: peca3Core1, isFake: true, subPeca: nil, isComplet: false)
            colisao(colisao1: fake1core1, colisao2: peca4Core1, isFake: true, subPeca: nil, isComplet: false)
            colisao(colisao1: fake1core1, colisao2: fake2core1, isFake: true, subPeca: nil, isComplet: false)
            colisao(colisao1: fake1core1, colisao2: peca1_2, isFake: true, subPeca: nil, isComplet: false)
            colisao(colisao1: fake1core1, colisao2: peca3_4, isFake: true, subPeca: nil, isComplet: false)
            colisao(colisao1: fake1core1, colisao2: peca1_3, isFake: true, subPeca: nil, isComplet: false)
            colisao(colisao1: fake1core1, colisao2: peca2_4, isFake: true, subPeca: nil, isComplet: false)
            colisao(colisao1: fake1core1, colisao2: peca1_2_3, isFake: true, subPeca: nil, isComplet: false)
            colisao(colisao1: fake1core1, colisao2: peca1_3_4, isFake: true, subPeca: nil, isComplet: false)
            colisao(colisao1: fake1core1, colisao2: peca1_2_4, isFake: true, subPeca: nil, isComplet: false)
            colisao(colisao1: fake1core1, colisao2: peca2_3_4, isFake: true, subPeca: nil, isComplet: false)
        case "fake2core1":
            colisao(colisao1: fake2core1, colisao2: peca1Core1, isFake: true, subPeca: nil, isComplet: false)
            colisao(colisao1: fake2core1, colisao2: peca2Core1, isFake: true, subPeca: nil, isComplet: false)
            colisao(colisao1: fake2core1, colisao2: peca3Core1, isFake: true, subPeca: nil, isComplet: false)
            colisao(colisao1: fake2core1, colisao2: peca4Core1, isFake: true, subPeca: nil, isComplet: false)
            colisao(colisao1: fake2core1, colisao2: fake1core1, isFake: true, subPeca: nil, isComplet: false)
            colisao(colisao1: fake2core1, colisao2: peca1_2, isFake: true, subPeca: nil, isComplet: false)
            colisao(colisao1: fake2core1, colisao2: peca3_4, isFake: true, subPeca: nil, isComplet: false)
            colisao(colisao1: fake2core1, colisao2: peca1_3, isFake: true, subPeca: nil, isComplet: false)
            colisao(colisao1: fake2core1, colisao2: peca2_4, isFake: true, subPeca: nil, isComplet: false)
            colisao(colisao1: fake2core1, colisao2: peca1_2_3, isFake: true, subPeca: nil, isComplet: false)
            colisao(colisao1: fake2core1, colisao2: peca1_3_4, isFake: true, subPeca: nil, isComplet: false)
            colisao(colisao1: fake2core1, colisao2: peca1_2_4, isFake: true, subPeca: nil, isComplet: false)
            colisao(colisao1: fake2core1, colisao2: peca2_3_4, isFake: true, subPeca: nil, isComplet: false)
        default:
            break
        }
        
        
        self.currentNode = nil
    }
    
    //FAZER A COLISAO DE DUAS PECAS
    func colisao(colisao1: SKSpriteNode?,colisao2: SKSpriteNode?, isFake: Bool, subPeca: SKSpriteNode?, isComplet: Bool?){
        if (currentNode!.frame.intersects(colisao2!.frame)), isFake == false{
            colisao1!.position = CGPoint(x: 1000, y: 1000)
            colisao1!.removeFromParent()
            colisao2!.position = CGPoint(x: 1000, y: 1000)
            colisao2!.removeFromParent()
            subPeca?.position = position7
            addChild(subPeca!)
            if isComplet!{
                self.girlSad.isHidden = true
                self.girlHappy.isHidden = false
                self.speakOftheGirl.text = "I'm feeling better now, thanks!"
            }
        }else if (currentNode!.frame.intersects(colisao2!.frame)){
            colisao2!.run(SKAction.sequence([SKAction.rotate(byAngle: degToRad(8.0), duration: 0.1),
                                            SKAction.rotate(byAngle: degToRad(-8.0), duration: 0.1),
                                            SKAction.rotate(byAngle: degToRad(-8.0), duration: 0.1),
                                            SKAction.rotate(byAngle: degToRad(8.0), duration: 0.1),
                                            SKAction.rotate(byAngle: degToRad(8.0), duration: 0.1),
                                            SKAction.rotate(byAngle: degToRad(-8.0), duration: 0.1),
                                            SKAction.rotate(byAngle: degToRad(0.0), duration: 0.1),]))
            currentNode!.run(SKAction.sequence([SKAction.rotate(byAngle: degToRad(8.0), duration: 0.1),
                                                SKAction.rotate(byAngle: degToRad(-8.0), duration: 0.1),
                                                SKAction.rotate(byAngle: degToRad(-8.0), duration: 0.1),
                                                SKAction.rotate(byAngle: degToRad(8.0), duration: 0.1),
                                                SKAction.rotate(byAngle: degToRad(8.0), duration: 0.1),
                                                SKAction.rotate(byAngle: degToRad(-8.0), duration: 0.1),
                                                SKAction.rotate(byAngle: degToRad(0.0), duration: 0.1),]))
        }
    }
    
    //TRERMIDINHA
    func degToRad(_ degree: Double) -> CGFloat {
        return CGFloat(degree / 180.0 * .pi)
    }
}


// Load the SKScene from 'GameScene.sks'
let sceneView = SKView(frame: CGRect(x:0 , y:0, width: width, height: height))
let scene = GameScene(size: sceneView.frame.size)

// Set the scale mode to scale to fit the window
scene.scaleMode = .aspectFill
// Present the scenes
sceneView.presentScene(scene)

PlaygroundPage.current.liveView = sceneView
